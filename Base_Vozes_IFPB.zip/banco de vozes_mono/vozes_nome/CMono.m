
% Lendo com wavread
nome_arquivo = input('Arquivo: ', 's')
% ex: avs_nome1
[x,Fs]=wavread(nome_arquivo);
%Inserir o nome do novo arquivo
nome_saida= input('nome do arquivo de saida: ', 's')
% ex: avsn1
x1=x(:,1);
x2=x(:,2);
xmono=(x1+x2)/2;

wavwrite(xmono,Fs,nome_saida);

